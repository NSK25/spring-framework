package com.uncc.internship.form;

public class PaperworkForm {


	private String placementID;
	private String supervisorEmail;
	private String notes;
	private String supervisorEvaluation;
	private String companyInfo;
	private String studentInfo;

	
	public String getPlacementID() {
		return placementID;
	}
	public void setPlacementID(String placementID) {
		this.placementID = placementID;
	}
	public String getSupervisorEmail() {
		return supervisorEmail;
	}
	public void setSupervisorEmail(String supervisorEmail) {
		this.supervisorEmail = supervisorEmail;
	}
	public String getNotes() {
		return notes;
	}
	public void setNotes(String notes) {
		this.notes = notes;
	}
	public String getSupervisorEvaluation() {
		return supervisorEvaluation;
	}
	public void setSupervisorEvaluation(String supervisorEvaluation) {
		this.supervisorEvaluation = supervisorEvaluation;
	}
	public String getCompanyInfo() {
		return companyInfo;
	}
	public void setCompanyInfo(String companyInfo) {
		this.companyInfo = companyInfo;
	}
	public String getStudentInfo() {
		return studentInfo;
	}
	public void setStudentInfo(String studentInfo) {
		this.studentInfo = studentInfo;
	}
}
