package com.uncc.internship.service;

import java.util.List;

public interface InternshipService {
	public StringBuilder getCompaniesIntershipOffer(String companyId);
	public StringBuilder getIntershipDetails(String internshipID);
}
