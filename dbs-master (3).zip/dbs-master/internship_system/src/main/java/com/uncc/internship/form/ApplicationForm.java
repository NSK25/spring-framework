package com.uncc.internship.form;

public class ApplicationForm {
 private String Status;

public String getStatus() {
	return Status;
}

public void setStatus(String status) {
	Status = status;
}
}
